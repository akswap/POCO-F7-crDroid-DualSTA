#!/system/bin/sh

MODDIR="${0%/*}"
LOG="$MODDIR/runtime.log"

until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 3
done

[ -f "$MODDIR/disable" ] && exit 0
sleep 15

log_msg() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
  SIZE="$(wc -c < "$LOG" 2>/dev/null)"
  if [ -n "$SIZE" ] && [ "$SIZE" -gt 32768 ]; then
    tail -n 100 "$LOG" > "$LOG.tmp" 2>/dev/null
    mv -f "$LOG.tmp" "$LOG" 2>/dev/null
  fi
}

get_ap_ifaces() {
  iw dev 2>/dev/null | awk '
    $1 == "Interface" { iface=$2 }
    $1 == "type" && $2 == "AP" && iface != "" { print iface }
  '
}

log_msg "combined monitor started"

while true; do
  COUNTRY="$(cmd wifi get-country-code 2>/dev/null)"
  if ! echo "$COUNTRY" | grep -q "US"; then
    cmd wifi force-country-code enabled US >/dev/null 2>&1
    iw reg set US >/dev/null 2>&1
    NEW_COUNTRY="$(cmd wifi get-country-code 2>/dev/null)"
    log_msg "country reapplied: ${COUNTRY:-unknown} -> ${NEW_COUNTRY:-unknown}"
  fi

  for IFACE in $(get_ap_ifaces); do
    INFO="$(iw dev "$IFACE" info 2>/dev/null)"
    FREQ="$(echo "$INFO" | awk '$1 == "channel" { gsub(/[()]/, "", $3); print $3; exit }')"
    TXPOWER="$(echo "$INFO" | awk '$1 == "txpower" { print $2; exit }')"

    [ -z "$FREQ" ] && continue
    [ "$FREQ" -lt 5925 ] 2>/dev/null && continue
    [ "$FREQ" -gt 7125 ] 2>/dev/null && continue
    [ -z "$TXPOWER" ] && continue

    if awk -v value="$TXPOWER" 'BEGIN { exit !((value + 0) <= 10) }'; then
      if iw dev "$IFACE" set txpower auto >/dev/null 2>&1; then
        sleep 1
        NEW_TXPOWER="$(iw dev "$IFACE" info 2>/dev/null | awk '$1 == "txpower" { print $2; exit }')"
        log_msg "$IFACE ${FREQ}MHz TX-auto: ${TXPOWER}dBm -> ${NEW_TXPOWER:-unknown}dBm"
      else
        log_msg "$IFACE ${FREQ}MHz TX-auto failed at ${TXPOWER}dBm"
      fi
    fi
  done

  sleep 10
done
