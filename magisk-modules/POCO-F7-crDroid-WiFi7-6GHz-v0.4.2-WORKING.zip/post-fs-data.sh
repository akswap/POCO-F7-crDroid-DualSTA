#!/system/bin/sh

MODDIR="${0%/*}"
LOG="$MODDIR/guard.log"
DEVICE="$(getprop ro.product.vendor.device)"
VENDOR_FP="$(getprop ro.vendor.build.fingerprint)"
EXPECTED_WIFI_JAR_SHA="c9e9f08f4be3400f1014a122afedcc4e1460194f527d47d513ffe42f22f2e52e"
ACTIVE_WIFI_JAR_SHA="$(sha256sum /apex/com.android.wifi/javalib/service-wifi.jar 2>/dev/null | awk '{print $1}')"

if [ "$DEVICE" != "onyx" ] || \
   ! echo "$VENDOR_FP" | grep -q "OS3.0.7.0.WOLMIXM" || \
   [ "$ACTIVE_WIFI_JAR_SHA" != "$EXPECTED_WIFI_JAR_SHA" ]; then
  {
    echo "Compatibility guard failed; module disabled for next boot."
    echo "device=$DEVICE"
    echo "vendor=$VENDOR_FP"
    echo "wifi_jar=$ACTIVE_WIFI_JAR_SHA"
  } > "$LOG"
  touch "$MODDIR/disable"
fi
