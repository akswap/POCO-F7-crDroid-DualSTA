POCO F7 crDroid Wi-Fi 7 + 6 GHz Camera-Safe v0.4.2
================================================

EXACT TEST TARGET
-----------------
Device: POCO F7 (onyx)
ROM: crDroid Android 16, v12.12, build 20260913
Vendor: OS3.0.7.0.WOLMIXM
Original hostapd SHA-256:
1622dc7e0ffe4205e806a0418eff87779cd4317a864f05865bbc986758087f5e
service-wifi.jar SHA-256:
c9e9f08f4be3400f1014a122afedcc4e1460194f527d47d513ffe42f22f2e52e

PURPOSE
-------
CAMERA-SAFE CHANGE
------------------
v0.4 globally replaced crDroid's android.hardware.wifi.common-V1 and
android.hardware.wifi.hostapd-V2 libraries with Xiaomi.eu versions. Testing
confirmed that the camera HAL then failed to create its DualSAT use case and
configure streams, even with Wi-Fi and hotspot disabled.

v0.4.1 preserved the original filenames but still created a module
/vendor/lib64 mount; device testing confirmed that disabling this entire mount
restored the camera.

v0.4.2 contains no module /vendor/lib64 tree. The Xiaomi.eu hostapd and all
three dependencies use unique X1/X2 names. They are stored under
/vendor/etc/wifi/hostapd_miui_libs, and only hostapd resolves that directory
through its embedded RUNPATH.

After installation verify that the original global hashes remain:
  android.hardware.wifi.common-V1-ndk.so
    ab2ccf0df8434d026197cc684c4bd74204a44838513471fccea59f88452c9764
  android.hardware.wifi.hostapd-V2-ndk.so
    3beb3bc4bffb702ed8bfb1f5be8172f43b2e70f91fd8d5ee91896bb038ab7908

The crDroid framework resource gates were successfully enabled manually, but
the original hotspot still reported EHT ops 0, eht_ch=0x0 and wifiStandard=6.
This guarded test supplies the EHT-capable hostapd stack and installs a signed,
persistent resource overlay. v0.2 replaces the failed boot-time fabricated
overlay method used by v0.1.

The RRO enables these framework gates:
- config_wifiSoftapIeee80211beSupported
- config_wifi11beSupportOverride
- config_wifi6ghzSupport
- config_wifiSoftap6ghzSupported

6 GHZ CHANGES
-------------
The installed vendor WCNSS file reported:
  BandCapability=3
  scan_mode_6ghz=0
  oem_6g_support_disable=1

v0.3 creates a systemless copy and changes only these keys:
  BandCapability=7
  scan_mode_6ghz=1
  oem_6g_support_disable=0

After boot it applies the US test country override so the self-managed Qualcomm
regulatory table can expose 6 GHz channels. The physical vendor partition is
not written.

6 GHZ TX-AUTO RECOVERY
----------------------
The tested 6 GHz hotspot started at 8.00 dBm after each hotspot restart. Running
"iw dev wlan1 set txpower auto" restored the driver-reported value to 24.00 dBm.

v0.4 dynamically detects active AP interfaces. It applies driver-controlled
TX-auto only when:
- interface type is AP
- frequency is between 5925 and 7125 MHz
- reported TX power is 10 dBm or lower

It does not alter 2.4 GHz or 5 GHz hotspot TX power and does not force a fixed
dBm value.

NOT INCLUDED
------------
- No Settings APK modification

INSTALL / TEST
--------------
1. Install this ZIP using Magisk, KernelSU, or APatch.
2. Reboot.
3. Use WPA3-Personal for any 6 GHz connection or hotspot.
4. Verify country and driver channels:

   cmd wifi get-country-code
   iw reg get
   dumpsys wifi | grep "SupportedChannelListIn6g"

5. Test standalone 6 GHz client scanning:

   cmd wifi start-scan
   sleep 12
   cmd wifi list-scan-results | awk 'NR==1 || ($2 >= 5925 && $2 <= 7125)'

6. Start the 6 GHz hotspot and run:

   iw dev wlan1 info

7. Verify TX-auto after waiting about 10 seconds:

   iw dev wlan1 info

   Expected tested result: txpower 24.00 dBm

8. Verify EHT logs:

   logcat -d -v threadtime | grep -i -E "getGeneration|ieee80211be=|EHT ops|eht_ch|SoftApInfo|Interface version" | tail -n 150

   dumpsys wifi | grep "mCurrentSoftApInfoMap"

SUCCESS
-------
The PC/client should report 802.11be on 5 GHz or 6 GHz. Android may continue to
show wifiStandard=6 because the crDroid framework is AIDL v3 while the tested
EHT hostapd service is AIDL v2; client negotiation is the authoritative proof.

For 6 GHz, iw dev wlan1 info should show a frequency between 5925 and 7125 MHz.

Runtime monitor log:
  /data/adb/modules/poco_f7_crdroid_wifi7_test/runtime.log

REGULATORY WARNING
------------------
This test persistently applies a US regulatory-domain override and requests the
driver's automatic TX-power setting for an affected 6 GHz AP. Spectrum rules
and permitted power levels vary by country. Use only where the selected
channels and power levels are legally permitted. The value printed by iw is not
proof of actual EIRP; firmware, regulatory, antenna, SAR and thermal limits
still apply.

ROLLBACK / RECOVERY
-------------------
If hotspot or Wi-Fi fails, disable or remove this module in the root manager
and reboot. If Android does not boot normally, use the root manager's safe mode
or recovery to create the module's disable file, then reboot:

  /data/adb/modules/poco_f7_crdroid_wifi7_test/disable

The module is systemless and does not write the physical vendor partition.
