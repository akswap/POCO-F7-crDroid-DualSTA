#!/system/bin/sh
resetprop -p persist.vendor.debug.wifi.hal.preset_interface_combination_idx 5
