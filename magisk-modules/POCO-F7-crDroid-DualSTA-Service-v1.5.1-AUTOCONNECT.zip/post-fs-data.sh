#!/system/bin/sh

MODDIR=${0%/*}
SRC="$MODDIR/system/product/overlay/POCOF7Wifi7Overlay.apk"
DST="/product/overlay/POCOF7Wifi7Overlay.apk"

chown root:root "$SRC"
chmod 0644 "$SRC"
chcon u:object_r:system_file:s0 "$SRC" 2>/dev/null

mount -o bind "$SRC" "$DST"
